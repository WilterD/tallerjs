# js-practice
Practica de fundamentos de JS

...

## taller n1: figuras y formulas

## taller n2: porcentajes y descuentos

## taller n3: arreglos

link a diapositivas: 
https://www.canva.com/design/DAFAWZoPnJo/eYYAjNLgO-7FoQdTzz9PPg/view?utm_content=DAFAWZoPnJo&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton
