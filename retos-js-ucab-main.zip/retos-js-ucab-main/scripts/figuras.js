//codigo del cuadrado



//codigo circulo 



//interaccion con html
function CalcularPerimCuadrado(){
    const input= document.getElementById("inputCuadrado");
    const value= input.value;
    //aqui llamas a tu funcion asignando su valor a una constante
    
    //mostraremos el valor de la constante con un: alert 
}

function CalcularAreaCuadrado(){
    const input= document.getElementById("inputCuadrado");
    const value= input.value;
    
} 

function CalcularAreaTriangulo(){
    const altura=document.getElementById("inputaltura");
    const valoraltura=altura.value;
    const base=document.getElementById("inputbase");
    const valorbase=base.value;

    
}

function CalcularPerimCirculo(){
    const input= document.getElementById("inputradio");
    const value= input.value;

    
}

function CalcularAreaCirculo(){
    const input= document.getElementById("inputradio");
    const value= input.value;

    
}